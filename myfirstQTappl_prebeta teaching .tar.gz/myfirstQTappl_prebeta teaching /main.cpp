#include "mainwindow.h"
#include <QApplication>
#include<QtCore/QCoreApplication>
#include "student.h"
#include<iostream>
#include<QDebug>
#include <QObject>
using namespace std;
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();

   //QObject:: Qstring mstr = "This is my first student database project";
    cout<<"This is my first QT program";
    student *s1 = new student();
    //Qdebug("Please Enter the marks of the student");
    //Just to test the code actually this has to be done by the professor//
   // int rollnumber;
    char *firstname = new char[30];
    char *lastname = new char[30];
    int rollnumber,social,math,english,science;
    std::cin>>rollnumber>>firstname>>lastname>>social>>math>>english>>science;
    s1->print(rollnumber,firstname,lastname,social, math,english ,science);
    cout<<("Please select the valid button");



    return a.exec();
}
