#include "student.h"
#include <iostream>

class studentData : public QSharedData
{
public:

};

student::student() : data(new studentData)
{

}

student::student(const student &rhs) : data(rhs.data)
{

}
void student:: print(int rollnumber , char *firstname,char *lastname, int social,int math , int english , int science)
{
     this->rollnumber = rollnumber;
     this->firstname = firstname;
     this->lastname = lastname;
     this->social = social;
     this->math = math;
     this->english = english;
     this->science = science;
      showall();

}
void student::showall()
{
    std::cout<<rollnumber<<firstname<<lastname<<social<<math<<english<<science;
}
student &student::operator=(const student &rhs)
{
    if (this != &rhs)
        data.operator=(rhs.data);
    return *this;
}

student::~student()
{

}
