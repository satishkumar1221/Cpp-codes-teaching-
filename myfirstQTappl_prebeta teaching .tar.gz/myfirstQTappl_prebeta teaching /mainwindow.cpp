#include "mainwindow.h"
#include "ui_mainwindow.h"
#include"qobject.h"
#include "student.h"
#include<QDebug>
#include <QObject>
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

}

void MainWindow::on_pushButton_2_clicked()
{
 connect(ui->pushButton_2,SIGNAL(clicked(bool)),
         ui->pushButton_4,SLOT(showMenu()));
}

void MainWindow::on_pushButton_4_clicked()
{
    student *s1 = new student();
    s1->showall();
    delete(s1);
}

MainWindow::~MainWindow()
{
    delete ui;
}
