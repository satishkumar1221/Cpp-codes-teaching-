#ifndef STUDENT_H
#define STUDENT_H

#include <QMainWindow>
#include <QObject>
#include <QSharedDataPointer>
#include <QWidget>
//#include <Qdebug>
class studentData;

class student
{
public:
    //int rollnumber;
    char *firstname = (char *)(malloc(30));
    char *lastname = (char *)(malloc(30));
    int rollnumber,social,math,english,science;
    public:
    student();
    student(const student &);
    student &operator=(const student &);
    ~student();
     void print(int rollnumber , char *firstname,char *lastname, int social,int math , int english , int science);
    void showall();
private:
    QSharedDataPointer<studentData> data;
};

#endif // STUDENT_H
